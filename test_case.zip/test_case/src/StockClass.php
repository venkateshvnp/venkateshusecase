<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

namespace drmonkeyninja;

class StockClass {
    
    //Declare the stock
    static $item_price=['A'=>50,'B'=>30,'C'=>20,'D'=>15,'E'=>5];
    static $specail_price=array(
                            'A'=>array('3'=>130),
                            'B'=>array('2'=>45),
                            'C'=>array('2'=>38,'3'=>50),
                            'D'=>array('A'=>5)    
                                );
            
    public static function itemPrice(){
           return self::$item_price;
         //array_merge(self::, self::$specail_price);
     }
     public static function specialPrice(){
           return self::$specail_price;
     }
     
      
}

//$print_array=StockClass::itemPrice();
//echo "<pre>";
//print_r($print_array);
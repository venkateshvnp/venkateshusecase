<?php
namespace drmonkeyninja;
include_once('StockClass.php');

use drmonkeyninja\StockClass;
class MainClass{  
    protected $itemlist_arr = array();
    protected $specialprice_arr = array();
    function __construct(array $itemlist_arr,array $specialprice_arr) {
        $this->itemlist_arr = $itemlist_arr;
        $this->specialprice_arr = $specialprice_arr;
    
  }
    
    public function init()
    {
       // echo "<pre>";print_r($this->itemlist_arr);print_r($this->specialprice_arr);die();
        if(@$_REQUEST['debug']==1){ //debug
            echo "<pre>";
            print_r($this->itemlist_arr); 
            print_r($this->specialprice_arr); 
            print_r($_REQUEST);
        }
        
        $request_data=$_REQUEST; //Assign to Request Data
        $total_amount=0;
        $itema_total = $this->calculateItemA($request_data,$this->itemlist_arr,$this->specialprice_arr);
        $itemb_total = $this->calculateItemB($request_data,$this->itemlist_arr,$this->specialprice_arr);
        $itemc_total = $this->calculateItemC($request_data,$this->itemlist_arr,$this->specialprice_arr);
        $itemd_total = $this->calculateItemD($request_data,$this->itemlist_arr,$this->specialprice_arr);
        $iteme_total = $this->calculateItemE($request_data,$this->itemlist_arr,$this->specialprice_arr);
        
        if(@$_REQUEST['debug'] ==1){
        echo "<pre>";print_r($itema_total);print_r($itemb_total);print_r($itemc_total);print_r($itemd_total);print_r($iteme_total);
        }
        //Calculate Total Elements
        $total_amount = $itema_total['amountA']+$itemb_total['amountB']+$itemc_total['amountC']+$itemd_total['amountD']+$iteme_total['amountE'];
      
       //Display Cart Items if request comming from the Web 
        if(@$request_data['display_web'] ==1){    
        echo "<h3>Thanks for shopping with US , Below detail bill</h3><br>";  
        echo ($request_data['qty1']) ?  ("Iteam A Given Quantity=>".$request_data['qty1']." Total Price =>".$itema_total['amountA']."<br>") : ""; 
        echo ($request_data['qty2']) ?  ("Iteam B Given Quantity=>".$request_data['qty2']." Total Price =>".$itemb_total['amountB']."<br>") : ""; 
        echo ($request_data['qty3']) ?  ("Iteam C Given Quantity=>".$request_data['qty3']." Total Price =>".$itemc_total['amountC']."<br>") : ""; 
        echo ($request_data['qty4']) ?  ("Iteam D Given Quantity=>".$request_data['qty4']." Total Price =>".$itemd_total['amountD']."<br>") : ""; 
        echo ($request_data['qty5']) ?  ("Iteam E Given Quantity=>".$request_data['qty5']." Total Price =>".$iteme_total['amountE']."<br>") : ""; 
        echo "Total Amount ==>".$total_amount;
        }
        
    }
    public function displayCartItems($request_data,$itema_total,$itemb_total,$itemc_total,$itemd_total,$iteme_total){
        
        
        
    }
    public function calculateItemA($request_data,$itemlist_arr,$specialprice_arr){
        
        $amountA=0; // initialise
        $offer_price = 0;
        $offer_quantity = 0;
        $error='';
        if(array_key_exists($request_data['select1'],$itemlist_arr)){
           
            if(!is_numeric($request_data['qty1'])){
                $error = 'Valid Quantity required for Item A';
                return ['amountA'=>$amountA,'error'=>$error];
            }
            //$result = array_values(array_column($specialprice_arr, $request_data['select1']));
            if($request_data['qty1']>0){
            $temp_arr = $specialprice_arr[$request_data['select1']];
            $offer_quantityarr = array_keys($temp_arr);
            $offer_pricearr = array_values($temp_arr);
            $offer_quantity = $offer_quantityarr[0];
            $offer_price = $offer_pricearr[0];
                      
            if($request_data['qty1']<$offer_quantity){
                $amountA = round($request_data['qty1']*$itemlist_arr[$request_data['select1']],2);
            }else{
                $amountA = ($request_data['qty1']%$offer_quantity)*$itemlist_arr[$request_data['select1']]; 
                $amountA += ((int)($request_data['qty1']/$offer_quantity))*$offer_price;
                
                }
            }    
        }
        return ['amountA'=>$amountA,'error'=>$error];
        
    }
    public function calculateItemB($request_data,$itemlist_arr,$specialprice_arr){
        
        $amountB=0; // initialise
        $offer_price = 0;
        $offer_quantity = 0;
        $error='';
        if(array_key_exists($request_data['select2'],$itemlist_arr)){
            
            if(!is_numeric($request_data['qty2'])){
                $error = 'Valid Quantity required for Item B';
                 return ['amountB'=>$amountB,'error'=>$error];
            }
            if($request_data['qty2']>0){
            //$result = array_values(array_column($specialprice_arr, $request_data['select1']));
            $temp_arr = $specialprice_arr[$request_data['select2']];
            $offer_quantityarr = array_keys($temp_arr);
            $offer_pricearr = array_values($temp_arr);
            $offer_quantity = $offer_quantityarr[0];
            $offer_price = $offer_pricearr[0];
                      
           
            if($request_data['qty2']<$offer_quantity){
                $amountB = round($request_data['qty2']*$itemlist_arr[$request_data['select2']],2);
            }else{
               
                $amountB = ($request_data['qty2']%$offer_quantity)*$itemlist_arr[$request_data['select2']]; 
                $amountB += ((int)($request_data['qty2']/$offer_quantity))*$offer_price;
                if(@$_REQUEST['debug']==1 ){
                echo "Bquantity".$request_data['qty2']."<br>";    
                echo ($request_data['qty2']%$offer_quantity)."<br>";
                echo $itemlist_arr[$request_data['select2']]."<br>";
                echo ((int)($request_data['qty2']/$offer_quantity))."<br>";
                echo $offer_price."<br>";
                echo $amountB;
                }
                
                }
            }    
        }
        
        return ['amountB'=>$amountB,'error'=>$error];
        
    }
    public function calculateItemC($request_data,$itemlist_arr,$specialprice_arr){
        
        $amountC = 0; // initialise
        $div_value= 0;
        $mod_value = 0;
        $offer_price1 = 0;
        $offer_quantity1 = 0;
        $offer_price2 = 0;
        $offer_quantity2 = 0;
        $error='';
        if(array_key_exists($request_data['select3'],$itemlist_arr)){
            
           
            if(!is_numeric($request_data['qty3'])){
                 echo "request_data".$request_data['qty3'];die;
                $error = 'Valid Quantity required for Item C';
                return ['amountC'=>$amountC,'error'=>$error];
            }
            //$result = array_values(array_column($specialprice_arr, $request_data['select1']));
            if($request_data['qty3']>0){
            $temp_arr = $specialprice_arr[$request_data['select3']];
            krsort($temp_arr); //Sort the value to know heigst value
            
            $offer_quantityarr = array_keys($temp_arr);
            $offer_pricearr = array_values($temp_arr);
            
            $offer_quantity1 = $offer_quantityarr[0];
            $offer_price1 = $offer_pricearr[0];
            
            $offer_quantity2 = $offer_quantityarr[1];
            $offer_price2 = $offer_pricearr[1];
            
            if($request_data['qty3']<2){
                $amountC = $request_data['qty3']*$itemlist_arr[$request_data['select3']]; //if less than 2 then multtply without offer price
            }
            else{
                $mod_value = ($request_data['qty3']%$offer_quantity1);
                $div_value = (int)($request_data['qty3']/$offer_quantity1); //type caste to int 
                $amountC = $div_value * $offer_price1;
                
                if($mod_value==2) $amountC = $amountC + $offer_price2; 
                if($mod_value==1) $amountC = $amountC + $itemlist_arr[$request_data['select3']]; 
                 
            }
          }
            
        }
        return ['amountC'=>$amountC,'error'=>$error];
        
    }
    public function calculateItemD($request_data,$itemlist_arr,$specialprice_arr){
        
        $amountD=0; // initialise
        $offer_price = 0;
        $offer_quantity = 0;
        $remaning = 0; //Remaining Value
        $error='';
        if(array_key_exists($request_data['select4'],$itemlist_arr)){
            
            if(!is_numeric($request_data['qty4'])){
                $error = 'Valid Quantity required for Item D';
                return ['amountD'=>$amountD,'error'=>$error];
            }
            //$result = array_values(array_column($specialprice_arr, $request_data['select1']));
            $temp_arr = $specialprice_arr[$request_data['select4']];
            $offer_quantityarr = array_keys($temp_arr);
            $offer_pricearr = array_values($temp_arr);
            $offer_quantity = $offer_quantityarr[0];
            $offer_price = $offer_pricearr[0];
            
            if($request_data['qty4']>0){
                if($request_data['qty1'] !='' && $request_data['qty1']>0){
                    if(($request_data['qty4']>$request_data['qty1']) ){
                                    //10 
                    $remaning = ($request_data['qty4'] - $request_data['qty1']) * $itemlist_arr[$request_data['select4']];
                    $amountD = $remaning + $request_data['qty1'] * $offer_price;

                    }elseif($request_data['qty1']>$request_data['qty4']){
                    $amountD = $offer_price * $request_data['qty4'];
                    }
                }else{
                    $amountD =  $request_data['qty4'] * $itemlist_arr[$request_data['select4']];
                }
            }
        }
        return ['amountD'=>$amountD,'error'=>$error];

    }
    public function calculateItemE($request_data,$itemlist_arr,$specialprice_arr){
        
        $amountE = 0; // initialise
        $error = ''; 
        
        if(array_key_exists($request_data['select5'],$itemlist_arr)){
           
            if(!is_numeric($request_data['qty5'])){
                $error = 'Valid Quantity required for Item E';
                 return ['amountE'=>$amountE,'error'=>$error];
            }
            if($request_data['qty5']>0){
                $amountE = $request_data['qty5'] * $itemlist_arr[$request_data['select5']];
                
            }else{
                //$error = 'In Valid Quantity required for Item E';
                //return $error;
            }
        }
       return ['amountE'=>$amountE,'error'=>$error];
        
    }
    
    //End of the class
}

//Create Object 
 if(@$_REQUEST['display_web']=='1'){
    $itemlist_arr=StockClass::itemPrice();
    $specialprice_arr=StockClass::specialPrice();
    //echo "<pre>";     print_r($specialprice_arr);print_r($specialprice_arr);die;
    $new = new MainClass($itemlist_arr,$specialprice_arr);
    
    $new->init(); 
 }

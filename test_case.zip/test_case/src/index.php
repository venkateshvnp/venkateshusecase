<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Basket Calculation</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <p>Item Price:</p>
        <table class="table table-striped table-dark " style="width: 40%;
    /* padding-left: 450px; */
    margin-left: 450px;">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item</th>
      <th scope="col">Unit Price</th>
      <th scope="col">Special Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>A</td>
      <td>50</td>
      <td>3 for 130</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>B</td>
      <td>30</td>
      <td>2 for 45</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>C</td>
      <td>20</td>
      <td>2 for 38 && 3 for 50</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>D</td>
      <td>15</td>
      <td>5 If Purchase with A</td>
    </tr>
    <tr>
      <th scope="row">5</th>
      <td>E</td>
      <td>15</td>
      <td>-</td>
    </tr>
  </tbody>
</table>
        
       
        <div style="    padding-left: 0;
    margin-left: 450px;">  
             <p>Shopping</p>
     <form name="calculate_frm" id="frmid" method="request" action="MainClass.php">
        <div class="row">
            <div class="col-sm-3">
            <div class="form-group">
            <label for="exampleFormControlSelect1">Item A</label>
            <select name="select1" class="form-control">
                <option value="A">A</option>
            </select>
            </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                     <label for=""></label>
                    <input type="text" name="qty1" class="form-control" id="qty1" placeholder="Enter Quantity" value="0">
                 </div>
             </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
            <div class="form-group">
            <label for="exampleFormControlSelect1">Item B</label>
            <select name="select2" class="form-control">
                <option value="B">B</option>
            </select>
            </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                     <label for=""></label>
                    <input type="text" name="qty2" class="form-control" id="qty2" placeholder="Enter Quantity" value="0">
                 </div>
             </div>
        </div>
         <div class="row">
            <div class="col-sm-3">
            <div class="form-group">
            <label for="exampleFormControlSelect1">Item C</label>
            <select name="select3" class="form-control">
                <option value="C">C</option>
            </select>
            </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                     <label for=""></label>
                    <input type="text" name="qty3" class="form-control" id="qty3" placeholder="Enter Quantity" value="0">
                 </div>
             </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
            <div class="form-group">
            <label for="exampleFormControlSelect1">Item D</label>
            <select name="select4" class="form-control">
                <option value="D">D</option>
            </select>
            </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                     <label for=""></label>
                    <input type="text" name="qty4" class="form-control" id="qty4" placeholder="Enter Quantity" value="0">
                 </div>
             </div>
        </div>    
         <div class="row">
            <div class="col-sm-3">
            <div class="form-group">
            <label for="exampleFormControlSelect1">Item E</label>
            <select name="select5" class="form-control">
                <option value="E">E</option>
            </select>
            </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label for=""></label>
                    <input type="text" name="qty5" class="form-control" id="qty5" placeholder="Enter Quantity" value="0">
                 </div>
             </div>
        </div>  
            <div class="row">
                <div class="col-sm-3">
                    <input style="padding-right: 12px;" type="submit" > 
                </div> 
            </div>   

         <input type="hidden" name="display_web" value="1">
        </form>
       </div> 
    </body>
</html>

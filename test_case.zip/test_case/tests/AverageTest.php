<?php

use drmonkeyninja\MainClass;
use PHPUnit\Framework\TestCase;
use drmonkeyninja\StockClass;
class AverageTest extends TestCase
{
    protected $Average;

    public function setUp()
    {
        
    }

  

    public function testCalculationOfIteamA()
    {
        $itemlist_arr=StockClass::itemPrice();
        $specialprice_arr=StockClass::specialPrice();
        $this->Average = new MainClass($itemlist_arr,$specialprice_arr);
        $numbers = ['select1'=>'A','qty1'=>12];
        $this->assertEquals(520, $this->Average->calculateItemA($numbers,$itemlist_arr,$specialprice_arr)['amountA']);
    }
    public function testCalculationOfIteamB()
    {
        $itemlist_arr=StockClass::itemPrice();
        $specialprice_arr=StockClass::specialPrice();
        $this->Average = new MainClass($itemlist_arr,$specialprice_arr);
        $numbers = ['select2'=>'B','qty2'=>5];
        $this->assertEquals(120, $this->Average->calculateItemB($numbers,$itemlist_arr,$specialprice_arr)['amountB']);
    }
    public function testCalculationOfIteamC()
    {
        $itemlist_arr=StockClass::itemPrice();
        $specialprice_arr=StockClass::specialPrice();
        $this->Average = new MainClass($itemlist_arr,$specialprice_arr);
        $numbers = ['select3'=>'C','qty3'=>6];
        $this->assertEquals(100, $this->Average->calculateItemC($numbers,$itemlist_arr,$specialprice_arr)['amountC']);
    }
    public function testCalculationOfIteamD()
    {
        $itemlist_arr=StockClass::itemPrice();
        $specialprice_arr=StockClass::specialPrice();
        $this->Average = new MainClass($itemlist_arr,$specialprice_arr);
        $numbers = ['select4'=>'D','qty4'=>7,'select1'=>'A','qty1'=>12];
        $this->assertEquals(35, $this->Average->calculateItemD($numbers,$itemlist_arr,$specialprice_arr)['amountD']);
    }
    public function testCalculationOfIteamE()
    {
        $itemlist_arr=StockClass::itemPrice();
        $specialprice_arr=StockClass::specialPrice();
        $this->Average = new MainClass($itemlist_arr,$specialprice_arr);
        $numbers = ['select5'=>'E','qty5'=>8];
        $this->assertEquals(40, $this->Average->calculateItemE($numbers,$itemlist_arr,$specialprice_arr)['amountE']);
    }
    public function testCalculationOfIteamDWithoutA()
    {
        $itemlist_arr=StockClass::itemPrice();
        $specialprice_arr=StockClass::specialPrice();
        $this->Average = new MainClass($itemlist_arr,$specialprice_arr);
        $numbers = ['select4'=>'D','qty4'=>7,'select1'=>'A','qty1'=>'0'];
        $this->assertEquals(105, $this->Average->calculateItemD($numbers,$itemlist_arr,$specialprice_arr)['amountD']);
    }
    
    
    
}

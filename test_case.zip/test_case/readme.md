=====================================

do composer update
=====================================


Check the Contents src folder

   src--->source code direcory
   
   test--->test script direcory
   
   index.php will gives you a UI to enter values
   
   
   Test script having  sample test cases 
   
   ======================================
   
   
   Enviroment requirements
   
   PHP 7.3
   PHP composer
   cmd or git cli
===============================================
  code deployment
  
   unZip the file place in new folder ex:test_units
   
  Run:
  http://localhost:8080/test_units/test_case/src/
  
  Note: Give the port number if you a have
  
  UI will be displayed 
  